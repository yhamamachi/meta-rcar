/*
 * Camera test application
 *
 * Copyright (C) 2016-2017 Renesas Electronics Corporation
 * Copyright (C) 2016-2017 Cogent Embedded, Inc. <source@cogentembedded.com>
 *
 * based on:
 *  V4L2 video capture example
 *  This program is provided with the V4L2 API
 *  see http://linuxtv.org/docs.php for more information
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <getopt.h>             /* getopt_long() */

#include <fcntl.h>              /* low-level i/o */
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>

#include <linux/videodev2.h>
#include <linux/fb.h>

#include <drm_fourcc.h>

#include "utest-common.h"
#include "utest-drm-display.h"


display_data_t  *display;
window_data_t      *window;
#define CLEAR(x) memset(&(x), 0, sizeof(x))

#define FIELD V4L2_FIELD_NONE

/* ...log level (looks ugly) */
int     LOG_LEVEL = 1;

struct buffer {
	void   *start;
	size_t  length;
	int     dmafd;
	texture_data_t *texture;
};

#define BUF_COUNT       4
#define N_DEVS_MAX      8
static char             n_devs = 1;
static char            *dev_name[N_DEVS_MAX] = {"/dev/video0","/dev/video1","/dev/video2","/dev/video3","/dev/video4","/dev/video5","/dev/video6","/dev/video7"};
static char            *fbdev_name;
static int              fd[N_DEVS_MAX] = {-1, -1, -1, -1, -1, -1, -1, -1};
struct buffer          *buffers[N_DEVS_MAX];
static unsigned int     n_buffers[N_DEVS_MAX];
static int              out_buf, out_fb;
static char             *format_name;
static int              frame_count = 70;
static int              fps_count = 0;
static int              framerate = 0;
static int              timeout = 60; // secs
static int              LEFT = 0;
static int              TOP = 0;
static int              WIDTH = 1280;
static int              HEIGHT = 800;
static int              DRMW = 1920;//1280;
static int              DRMH = 1080;//720;
#define DRM_FORMAT      DRM_FORMAT_BGRX8888
//#define DRM_FORMAT      DRM_FORMAT_RGBX8888

static void errno_exit(const char *s)
{
	fprintf(stderr, "%s error %d, %s\n", s, errno, strerror(errno));
	exit(EXIT_FAILURE);
}

static int xioctl(int fh, int request, void *arg)
{
	int r;

	do {
		r = ioctl(fh, request, arg);
	} while (-1 == r && EINTR == errno);

	return r;
}

static inline unsigned long uSecElapsed(struct timeval *t2, struct timeval *t1)
{
	return (t2->tv_sec - t1->tv_sec) * 1000000 + t2->tv_usec - t1->tv_usec;
}

static void fpsCount(int dev)
{
	static unsigned frames[N_DEVS_MAX];
	static struct timeval frame_time[N_DEVS_MAX];
	static unsigned long usec[N_DEVS_MAX];
	struct timeval t;

	gettimeofday(&t, NULL);
	usec[dev] += frames[dev]++ ? uSecElapsed(&t, &frame_time[dev]) : 0;
	frame_time[dev] = t;
	if (usec[dev] >= 1000000) {
		unsigned fps = ((unsigned long long)frames[dev] * 10000000 + usec[dev] - 1) / usec[dev];
		fprintf(stderr, "%s FPS: %3u.%1u\n", dev_name[dev], fps / 10, fps % 10);
		usec[dev] = 0;
		frames[dev] = 0;
	}
}

#define min(a,b) (a<b?a:b)

static void process_image_drm(int dev, int i)
{
	texture_data_t     *t = (buffers[dev])[i].texture;
	texture_view_t      v;
	texture_crop_t      c;

	/* ...set view-port for a buffer */
	texture_set_view(&v, 0, 0, min(DRMW,WIDTH), min(DRMH,HEIGHT));

	/* ...set cropping parameters */
	texture_set_crop(&c, 0, 0, min(DRMW,WIDTH), min(DRMH,HEIGHT));

	/* ...setup rendering plane */
	plane_setup(window, 0, t, NULL, 0xFF, &v, &c, NULL, 0);

	/* ...submit data to renderer */
	window_draw(window);
}

static int read_frame(int dev)
{
	struct v4l2_buffer buf;

	CLEAR(buf);
	buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	buf.memory = V4L2_MEMORY_MMAP;

	if (-1 == xioctl(fd[dev], VIDIOC_DQBUF, &buf)) {
		switch (errno) {
			case EAGAIN:
				return 0;
			case EIO:
				/* Could ignore EIO, see spec. */
				/* fall through */
			default:
				errno_exit("VIDIOC_DQBUF");
		}
	}

	assert(buf.index < n_buffers[dev]);

	process_image_drm(dev, buf.index);

	if (-1 == xioctl(fd[dev], VIDIOC_QBUF, &buf))
		errno_exit("VIDIOC_QBUF");

	if (fps_count)
		fpsCount(dev);

	return 1;
}

#define max(a,b) (a>b?a:b)

static void mainloop(void)
{
	unsigned int count = frame_count;
	int dev = 0;
	fd_set fds;
	struct timeval tv;
	int r;

	/* Give time to queue buffers at start streaming by VIN module */
	usleep(34000*3);

	while (count-- > 0) {
		for (;;) {
			FD_ZERO(&fds);

			for (dev = 0; dev < n_devs; dev++)
				FD_SET(fd[dev], &fds);
			/* Timeout. */
			tv.tv_sec = timeout;
			tv.tv_usec = 0;

			r = select(max(max(max(fd[0],fd[1]),max(fd[2],fd[3])),max(max(fd[4],fd[5]),max(fd[6],fd[7]))) + 1, &fds, NULL, NULL, &tv);
			if (-1 == r) {
				if (EINTR == errno)
					continue;
				errno_exit("select");
			}

			if (0 == r) {
				fprintf(stderr, "select timeout\n");
				exit(EXIT_FAILURE);
			}

			r = 0;
			for (dev = 0; dev < n_devs; dev++) {
				if (FD_ISSET(fd[dev], &fds))
					r += read_frame(dev);
			}
			if (r)
				break;
			/* EAGAIN - continue select loop. */
		}
	}
}

static void stop_capturing(int dev)
{
	enum v4l2_buf_type type;

	type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (-1 == xioctl(fd[dev], VIDIOC_STREAMOFF, &type))
		errno_exit("VIDIOC_STREAMOFF");
}

static void start_capturing(int dev)
{
	unsigned int i;
	enum v4l2_buf_type type;

	for (i = 0; i < n_buffers[dev]; ++i) {
		struct v4l2_buffer buf;

		CLEAR(buf);
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.index = i;
		if (-1 == xioctl(fd[dev], VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");
	}

	type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (-1 == xioctl(fd[dev], VIDIOC_STREAMON, &type))
		errno_exit("VIDIOC_STREAMON");
}

static void uninit_device(int dev)
{
	unsigned int i;

	for (i = 0; i < n_buffers[dev]; ++i)
		if (-1 == munmap((buffers[dev])[i].start, (buffers[dev])[i].length))
			errno_exit("munmap");

	free(buffers[dev]);
}

static void init_mmap(int dev)
{
	unsigned int i;
	struct v4l2_requestbuffers req;

	CLEAR(req);

	req.count = BUF_COUNT;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	req.memory = V4L2_MEMORY_MMAP;

	if (-1 == xioctl(fd[dev], VIDIOC_REQBUFS, &req)) {
		if (EINVAL == errno) {
			fprintf(stderr, "%s does not support "
					"memory mapping\n", dev_name[dev]);
			exit(EXIT_FAILURE);
		} else {
			errno_exit("VIDIOC_REQBUFS");
		}
	}

	if (req.count < 2) {
		fprintf(stderr, "Insufficient buffer memory on %s\n",
				dev_name[dev]);
		exit(EXIT_FAILURE);
	}

	buffers[dev] = calloc(req.count, sizeof(*buffers[dev]));

	if (!buffers[dev]) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}

	for (n_buffers[dev] = 0; n_buffers[dev] < req.count; ++n_buffers[dev]) {
		struct v4l2_buffer buf;

		CLEAR(buf);

		buf.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory      = V4L2_MEMORY_MMAP;
		buf.index       = n_buffers[dev];

		if (-1 == xioctl(fd[dev], VIDIOC_QUERYBUF, &buf))
			errno_exit("VIDIOC_QUERYBUF");

		(buffers[dev])[n_buffers[dev]].length = buf.length;
		(buffers[dev])[n_buffers[dev]].start =
			mmap(NULL /* start anywhere */,
					buf.length,
					PROT_READ | PROT_WRITE /* required */,
					MAP_SHARED /* recommended */,
					fd[dev], buf.m.offset);

		if (MAP_FAILED == (buffers[dev])[n_buffers[dev]].start)
			errno_exit("mmap");
	}

	for (i = 0; i < req.count; i++) {
		struct v4l2_exportbuffer    expbuf;
		u32 offset[4];
		u32 stride[4];


		/* ...emit export request */
		memset(&expbuf, 0, sizeof(expbuf));
		expbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		expbuf.index = i;
		xioctl(fd[dev], VIDIOC_EXPBUF, &expbuf);

		/* ...we have single plane only */
		if (!strncmp(format_name, "xrgb", 4)) {
			(buffers[dev])[i].dmafd = expbuf.fd;
			stride[0] = WIDTH*4;
			offset[0] = 0;
			(buffers[dev])[i].texture = texture_create(WIDTH, HEIGHT, DRM_FORMAT, expbuf.fd, offset, stride);
		} else {
			fprintf(stderr, "DRM output: Only XRGB is supported now\n");
			exit(EXIT_FAILURE);
		}
	}

}

static void deinit_mmap(int dev)
{
	/* TBD: destroy textures */
	return;
}

static void init_device(int dev)
{
	struct v4l2_capability cap;
	struct v4l2_cropcap cropcap;
	struct v4l2_crop crop;
	struct v4l2_format fmt;

	if (-1 == xioctl(fd[dev], VIDIOC_QUERYCAP, &cap)) {
		if (EINVAL == errno) {
			fprintf(stderr, "%s is no V4L2 device\n",
					dev_name[dev]);
			exit(EXIT_FAILURE);
		} else {
			errno_exit("VIDIOC_QUERYCAP");
		}
	}

	if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
		fprintf(stderr, "%s is no video capture device\n",
				dev_name[dev]);
		exit(EXIT_FAILURE);
	}

	if (!(cap.capabilities & V4L2_CAP_STREAMING)) {
		fprintf(stderr, "%s does not support streaming i/o\n",
			dev_name[dev]);
			exit(EXIT_FAILURE);
	}

	/* Select video input, video standard and tune here. */
	CLEAR(cropcap);
	cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (0 == xioctl(fd[dev], VIDIOC_CROPCAP, &cropcap)) {
		crop.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		crop.c = cropcap.defrect; /* reset to default */

		crop.c.left = LEFT;
		crop.c.top = TOP;
		crop.c.width = WIDTH;
		crop.c.height = HEIGHT;

		if (-1 == xioctl(fd[dev], VIDIOC_S_CROP, &crop)) {
			switch (errno) {
				case EINVAL:
					/* Cropping not supported. */
					break;
				default:
					/* Errors ignored. */
					break;
			}
		}
	} else {
		/* Errors ignored. */
	}

	if (framerate) {
		struct v4l2_streamparm parm;

		parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		if (-1 == xioctl(fd[dev], VIDIOC_G_PARM, &parm))
			errno_exit("VIDIOC_G_PARM");

		parm.parm.capture.timeperframe.numerator = 1;
		parm.parm.capture.timeperframe.denominator = framerate;
		if (-1 == xioctl(fd[dev], VIDIOC_S_PARM, &parm))
			errno_exit("VIDIOC_S_PARM");
	}

#if 0
	struct v4l2_control control;

	memset(&control, 0, sizeof (control));
	control.id = V4L2_CID_BRIGHTNESS;
	//    control.id = V4L2_CID_VFLIP;
	//    control.id = V4L2_CID_CONTRAST;
	//    control.id = V4L2_CID_SATURATION;
	//    control.id = V4L2_CID_GAMMA;
	//    control.id = V4L2_CID_GAIN;
	//    control.id = V4L2_CID_EXPOSURE;
	//    control.id = V4L2_CID_AUTOGAIN;

	if (-1 == xioctl(fd[dev], VIDIOC_G_CTRL, &control))
		errno_exit("VIDIOC_G_CTRL");

	control.value = 0xf0;

	if (-1 == ioctl(fd[dev], VIDIOC_S_CTRL, &control))
		errno_exit("VIDIOC_S_CTRL");
#endif

	CLEAR(fmt);

	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	fmt.fmt.pix.width  = WIDTH;
	fmt.fmt.pix.height = HEIGHT;
	fmt.fmt.pix.field  = FIELD;

	if (!strncmp(format_name, "uyvy", 4))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_UYVY;
	else if (!strncmp(format_name, "yuyv", 4))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
	else if (!strncmp(format_name, "rgb565", 6))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB565;
	else if (!strncmp(format_name, "rgb32", 5))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_XBGR32;
	else if (!strncmp(format_name, "xrgb", 4))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_XBGR32;
	else if (!strncmp(format_name, "nv12", 4))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_NV12;
	else if (!strncmp(format_name, "nv16", 4))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_NV16;
	else if (!strncmp(format_name, "bggr8", 5))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_SBGGR8;
	else if (!strncmp(format_name, "bggr12", 6))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_SBGGR12;
	else if (!strncmp(format_name, "bggr16", 6))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_SBGGR16;
	else if (!strncmp(format_name, "cccc16", 6))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_SBGGR8;
	else if (!strncmp(format_name, "grey", 4))
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_GREY;
	else {
		/* Preserve original settings as set by v4l2-ctl for example */
		if (-1 == xioctl(fd[dev], VIDIOC_G_FMT, &fmt))
			errno_exit("VIDIOC_G_FMT");
	}

	if (-1 == xioctl(fd[dev], VIDIOC_S_FMT, &fmt))
		errno_exit("VIDIOC_S_FMT");

	//printf("fmt.fmt.pix.bytesperline =%d\n\n\n",fmt.fmt.pix.bytesperline);

	init_mmap(dev);
}

static void close_device(int dev)
{
	deinit_mmap(dev);

	if (-1 == close(fd[dev]))
		errno_exit("close");

	fd[dev] = -1;
}

static void open_device(int dev)
{
	struct stat st;

	if (-1 == stat(dev_name[dev], &st)) {
		fprintf(stderr, "Cannot identify '%s': %d, %s\n",
				dev_name[dev], errno, strerror(errno));
		exit(EXIT_FAILURE);
	}

	if (!S_ISCHR(st.st_mode)) {
		fprintf(stderr, "%s is no device\n", dev_name[dev]);
		exit(EXIT_FAILURE);
	}

	fd[dev] = open(dev_name[dev], O_RDWR /* required */ | O_NONBLOCK, 0);

	if (-1 == fd[dev]) {
		fprintf(stderr, "Cannot open '%s': %d, %s\n",
				dev_name[dev], errno, strerror(errno));
		exit(EXIT_FAILURE);
	}
}

/* ...processing window parameters */
static window_info_t app_main_info = {
	.fullscreen = 1,
};

/* ...main window widget parameters (input-interface + GUI?) */
static widget_info_t app_main_info2 = {
	.init = NULL,
};

static void init_drm_display()
{
	/* ...initialize display subsystem */
	display = display_create();
	if (!display) {
		fprintf(stderr, "Cannot create DRM display\n");
		exit(EXIT_FAILURE);
	}

	app_main_info.width = DRMW;
	app_main_info.height = DRMH;
	window = window_create(display, &app_main_info, &app_main_info2, NULL);
	return;
}

static void deinit_drm_display()
{
	/* TBD */
	return;
}

static void usage(FILE *fp, char **argv)
{
	fprintf(fp,
			"Usage: %s [options]\n\n"
			"Version 1.3\n"
			"Options:\n"
			"-d | --device name   Video device name [%s]\n"
			"-D | --ndev          Number of devices to capture simultaneously [%d]\n"
			"-h | --help          Print this message\n"
			"-o | --output        Outputs stream to stdout\n"
			"-F | --output_fb     Outputs stream to framebuffer\n"
			"-f | --format        Set pixel format: uyvy, yuyv, rgb565, rgb32, nv12, nv16, bggr8, bggr16, cccc16, grey [%s]\n"
			"-c | --count         Number of frames to grab [%i]\n"
			"-z | --fps_count     Enable fps show\n"
			"-s | --framerate     Set framerate\n"
			"-L | --left          Video left crop [%i]\n"
			"-T | --top           Video top crop [%i]\n"
			"-W | --width         Video width [%i]\n"
			"-H | --height        Video height [%i]\n"
			"-X | --drmw          Output (VSP/DRM) width  [%i]\n"
			"-Y | --drmh          Output (VSP/DRM) height  [%i]\n"
			"-t | --timeout       Select timeout [%i]sec\n"
			"",
		argv[0], dev_name[0], n_devs, format_name, frame_count, LEFT, TOP, WIDTH, HEIGHT, DRMW, DRMH, timeout);
}

static const char short_options[] = "d:D:hmruoFf:c:zs:L:T:W:H:X:Y:t:";

static const struct option
long_options[] = {
	{ "device", required_argument, NULL, 'd' },
	{ "ndev",   required_argument, NULL, 'D' },
	{ "help",   no_argument,       NULL, 'h' },
	{ "output", no_argument,       NULL, 'o' },
	{ "output_fb", no_argument,    NULL, 'F' },
	{ "format", required_argument, NULL, 'f' },
	{ "count",  required_argument, NULL, 'c' },
	{ "fps_count",  required_argument, NULL, 'z' },
	{ "framerate",  required_argument, NULL, 's' },
	{ "left",  required_argument, NULL, 'L' },
	{ "top",  required_argument, NULL, 'T' },
	{ "width",  required_argument, NULL, 'W' },
	{ "height",  required_argument, NULL, 'H' },
	{ "drmw",  required_argument, NULL, 'X' },
	{ "drmh",  required_argument, NULL, 'Y' },
	{ "timeout",  required_argument, NULL, 't' },
	{ 0, 0, 0, 0 }
};

int main(int argc, char **argv)
{
	int dev;
	dev_name[0] = "/dev/video0";
	fbdev_name = "/dev/fb0";
	format_name = "uyvy";

	for (;;) {
		int idx;
		int c;

		c = getopt_long(argc, argv,
				short_options, long_options, &idx);

		if (-1 == c)
			break;

		switch (c) {
			case 0: /* getopt_long() flag */
				break;

			case 'd':
				dev_name[0] = optarg;
				break;

			case 'D':
				errno = 0;
				n_devs = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'h':
				usage(stdout, argv);
				exit(EXIT_SUCCESS);

			case 'o':
				out_buf++;
				break;

			case 'F':
				out_fb++;
				break;

			case 'f':
				format_name = optarg;
				break;

			case 'c':
				errno = 0;
				frame_count = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'z':
				fps_count = 1;
				break;

			case 's':
				errno = 0;
				framerate = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'L':
				errno = 0;
				LEFT = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'T':
				errno = 0;
				TOP = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'W':
				errno = 0;
				WIDTH = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'H':
				errno = 0;
				HEIGHT = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'X':
				errno = 0;
				DRMW = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 'Y':
				errno = 0;
				DRMH = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			case 't':
				errno = 0;
				timeout = strtol(optarg, NULL, 0);
				if (errno)
					errno_exit(optarg);
				break;

			default:
				usage(stderr, argv);
				exit(EXIT_FAILURE);
		}
	}

	init_drm_display();
	for (dev = 0; dev < n_devs; dev++) {
		open_device(dev);
		init_device(dev);
		start_capturing(dev);
	}

	mainloop();

	for (dev = 0; dev < n_devs; dev++) {
		stop_capturing(dev);
		uninit_device(dev);
		close_device(dev);
	}
	deinit_drm_display();

	return 0;
}
