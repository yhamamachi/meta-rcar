/*******************************************************************************
 * utest-drm-display.c
 *
 * Display support for unit-test application (generic DRM)
 *
 * Copyright (c) 2014-2017 Cogent Embedded Inc. ALL RIGHTS RESERVED.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *******************************************************************************/

#define MODULE_TAG                      DISPLAY

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "utest-common.h"
#include "utest-drm-display.h"
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/poll.h>
#include <sys/epoll.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>
#include <libudev.h>
#include <rcar_du_drm.h>

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);
TRACE_TAG(INFO, 1);
TRACE_TAG(EVENT, 1);
TRACE_TAG(DEBUG, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

typedef struct __list   __list_t;

struct __list
{
	struct __list  *next, *prev;
};

static inline void __list_init(__list_t *head)
{
	head->next = head->prev = head;
}

static inline int __list_is_empty(__list_t *head)
{
	return (head->next == head);
}

static inline void __list_push_tail(__list_t *head, __list_t *item)
{
	head->prev->next = item, item->prev = head->prev;
	item->next = head, head->prev = item;
}

static inline void __list_push_head(__list_t *head, __list_t *item)
{
	head->next->prev = item, item->next = head->next;
	item->prev = head, head->next = item;
}

static inline void __list_delete(__list_t *item)
{
	item->prev->next = item->next, item->next->prev = item->prev;
	item->prev = item->next = NULL;
}

static inline __list_t * __list_pop_head(__list_t *head)
{
	__list_t   *item = head->next;

	if (item != head)
	{
		__list_delete(item);
		return item;
	}
	else
	{
		return NULL;
	}
}

static inline __list_t * __list_pop_tail(__list_t *head)
{
	__list_t   *item = head->prev;

	if (item != head)
	{
		__list_delete(item);
		return item;
	}
	else
	{
		return NULL;
	}
}

static inline __list_t * list_null(__list_t *head)
{
	return head;
}

static inline __list_t * list_first(__list_t *head)
{
	return head->next;
}

static inline __list_t * list_last(__list_t *head)
{
	return head->prev;
}

static inline __list_t * list_next(__list_t *head, __list_t *item)
{
	return item->next;
}

static inline __list_t * list_prev(__list_t *head, __list_t *item)
{
	return item->prev;
}

/*******************************************************************************
 * Window data
 ******************************************************************************/

/* ...output device data */
typedef struct output_data
{
	/* ...link item in the outputs list */
	__list_t                    link;

	/* ...output device id */
	int                         id;

	/* ...scanout source id */
	uint32_t                    crtc;

	/* ...DRM connector id */
	uint32_t                    connector_id;

	/* ...current output device width / height */
	u32                         width, height;

	/* ...original DRM mode */
	drmModeModeInfo             mode, *current_mode;

	/* ...supported modes */
	drmModeModeInfo            *modes;

	/* ...number of modes */
	int                         modes_num;

}   output_data_t;

/* ...DRM properties */
enum display_prop
{
	PROP_FB_ID,
	PROP_CRTC_ID,
	PROP_CRTC_X,
	PROP_CRTC_Y,
	PROP_CRTC_W,
	PROP_CRTC_H,
	PROP_SRC_X,
	PROP_SRC_Y,
	PROP_SRC_W,
	PROP_SRC_H,
	PROP_ZPOS,
	PROP_ALPHA,
	PROP_ALPHAPLANE,
	PROP_BLEND,
	PROP_CKEY,
	PROP_CKEY_SET0,
	PROP_CKEY_SET1,
	PROP_NUMBER
};

/* ...display data */
struct display_data
{
	/* ...DRM device file handle */
	int                         fd;

	/* ...list of outputs */
	__list_t                    outputs;

	/* ...list of attached windows */
	__list_t                    windows;

	/* ...plane identifiers (tbd) */
	uint32_t                    plane_id[16];

	/* ...plane properties */
	uint32_t                    prop[PROP_NUMBER];

	/* ...dispatch loop epoll descriptor */
	int                         efd;

	/* ...pending display event status */
	int                         pending;

	/* ...dispatch thread handle */
	pthread_t                   thread;

	/* ...display lock (need that really? - tbd) */
	pthread_mutex_t             lock;
};

/* ...widget data structure */
struct widget_data
{
	/* ...reference to owning window */
	window_data_t              *window;

	/* ...reference to parent widget (not used yet - tbd) */
	widget_data_t              *parent;

	/* ...pointer to the user-provided widget info */
	widget_info_t              *info;

	/* ...widget client data */
	void                       *cdata;

	/* ...actual widget dimensions */
	int                         left, top, width, height;

	/* ...surface update request */
	int                         dirty;
};

/* ...output window data */
struct window_data
{
	/* ...root widget data (must be first) */
	widget_data_t               widget;

	/* ...reference to a display data */
	display_data_t             *display;

	/* ...output device handle */
	output_data_t              *output;

	/* ...modeset initialization flag - tbd */
	int                         modeset;

	/* ...frame-buffer identifiers (should be two) */
	uint32_t                    fb_id;

	/* ...list node in display windows list */
	__list_t                    link;

	/* ...window information */
	const window_info_t        *info;

	/* ...client data for a callback */
	void                       *cdata;

	/* ...atomic request pointer */
	drmModeAtomicReqPtr         atomic_req;

	/* ...internal data access lock */
	pthread_mutex_t             lock;

	/* ...conditional variable for rendering thread */
	pthread_cond_t              wait;

	/* ...window rendering thread */
	pthread_t                   thread;

	/* ...processing flags */
	u32                         flags;
};

/*******************************************************************************
 * Window processing flags
 ******************************************************************************/

/* ...redraw command pending */
#define WINDOW_FLAG_REDRAW              (1 << 0)

/* ...buffer busyness flag */
#define WINDOW_FLAG_BUSY                (1 << 1)

/* ...pending redraw request */
#define WINDOW_FLAG_MODESET             (1 << 2)

/* ...termination command pending */
#define WINDOW_FLAG_TERMINATE           (1 << 3)


/*******************************************************************************
 * Local variables
 ******************************************************************************/

/* ...this should be singleton for now - tbd */
static display_data_t   __display;

/*******************************************************************************
 * DRM support
 ******************************************************************************/

static struct udev_device * find_drm(struct udev * udev, const char *seat_id)
{
	struct udev_enumerate  *e;
	struct udev_list_entry *entry;
	struct udev_device     *drm_device = NULL;

	/* ...enumerate all DRM devices */
	CHK_ERR(e = udev_enumerate_new(udev), NULL);
	udev_enumerate_add_match_subsystem(e, "drm");
	udev_enumerate_add_match_sysname(e, "card[0-9]*");
	udev_enumerate_scan_devices(e);

	/* ...find device that has required SEAT id */
	udev_list_entry_foreach(entry, udev_enumerate_get_list_entry(e))
	{
		const char         *path = udev_list_entry_get_name(entry);
		struct udev_device *device;

		/* ...get device handle */
		if ((device = udev_device_new_from_syspath(udev, path)) == NULL)
		{
			TRACE(ERROR, _x("failed to create device: %m"));
			goto out;
		}

		/* ...check if seat id is specified */
		if (seat_id)
		{
			const char *id = udev_device_get_property_value(device, "ID_SEAT");

			if (!id || strcmp(seat_id, id) != 0)
			{
				TRACE(INFO, _b("skip device '%s': seat-id = %s (expected %s)"), path, id, seat_id);
				udev_device_unref(device);
				continue;
			}
		}

		TRACE(INFO, _b("found DRM device: '%s'"), path);
		drm_device = device;
		goto out;
	}

	TRACE(ERROR, _b("no DRM found (seat-id = %s)"), seat_id);

out:
	/* ...deallocate enumeration structure */
	udev_enumerate_unref(e);

	/* ...return device handle */
	return drm_device;
}

static int init_drm(struct udev_device *device)
{
	display_data_t             *display = &__display;
	const char                 *filename, *sysnum;
	int                         id;
	int                         fd;
	drmModePlaneRes            *plane_res;
	drmModeObjectProperties    *props;
	unsigned                    i;

	/* ...get device number */
	CHK_ERR(sysnum = udev_device_get_sysnum(device), -errno);

	/* ...save device identifier (need that? - tbd) */
	id = atoi(sysnum);

	/* ...get device filename */
	CHK_ERR(filename = udev_device_get_devnode(device), -errno);

	/* ...open file descriptor */
	if ((fd = open(filename, O_RDWR)) < 0)
	{
		TRACE(ERROR, _x("failed to open '%s': %m"), filename);
		return -errno;
	}
	else if (drmSetClientCap(fd, /*DRM_CLIENT_CAP_UNIVERSAL_PLANES*/DRM_CLIENT_CAP_ATOMIC, 1) < 0)
	{
		TRACE(ERROR, _x("failed to set caps: %m"));
		return -errno;
	}
	else if ((plane_res = drmModeGetPlaneResources(fd)) == NULL)
	{
		TRACE(ERROR, _x("failed to get planes resources: %m"));
		close(fd);
		return -errno;
	}

	/* ...go through all planes */
	for (i = 0; i < plane_res->count_planes; i++)
	{
		drmModePlane    *plane = drmModeGetPlane(fd, plane_res->planes[i]);

		/* ...just dump the planes for a moment? - tbd */
		TRACE(INFO, _b("plane-id: %d"), plane->plane_id);

		//sprite->possible_crtcs = plane->possible_crtcs;
		//sprite->plane_id = plane->plane_id;
		//sprite->current = NULL;
		//sprite->next = NULL;
		//sprite->backend = b;
		//sprite->count_formats = plane->count_formats;
		//memcpy(sprite->formats, plane->formats, plane->count_formats * sizeof(plane->formats[0]));

		display->plane_id[i] = plane->plane_id;

		/* ...release plane handle */
		drmModeFreePlane(plane);
	}

	/* ...release plane resources */
	drmModeFreePlaneResources(plane_res);

	/* ...query plane properties */
	if ((props = drmModeObjectGetProperties(fd, display->plane_id[0], DRM_MODE_OBJECT_PLANE)) == NULL)
	{
		TRACE(ERROR, _x("failed to get plane properties: %m"));
		close(fd);
		return -errno;
	}

	for (i = 0; i < props->count_props; i++)
	{
		uint32_t            prop_id = props->props[i];
		drmModePropertyPtr  prop;

		if ((prop = drmModeGetProperty(fd, prop_id)) == NULL)
		{
			TRACE(ERROR, _x("failed to get property #%u (of %u): %m"), i, props->count_props);
			continue;
		}

		TRACE(INFO, _b("property #%u: '%s' (id=%u) = %llu"), i, prop->name, prop_id, (unsigned long long)props->prop_values[i]);

		if (strcmp(prop->name, "FB_ID") == 0)
		{
			display->prop[PROP_FB_ID] = prop_id;
		}
		else if (strcmp(prop->name, "CRTC_ID") == 0)
		{
			display->prop[PROP_CRTC_ID] = prop_id;
		}
		else if (strcmp(prop->name, "CRTC_X") == 0)
		{
			display->prop[PROP_CRTC_X] = prop_id;
		}
		else if (strcmp(prop->name, "CRTC_Y") == 0)
		{
			display->prop[PROP_CRTC_Y] = prop_id;
		}
		else if (strcmp(prop->name, "CRTC_W") == 0)
		{
			display->prop[PROP_CRTC_W] = prop_id;
		}
		else if (strcmp(prop->name, "CRTC_H") == 0)
		{
			display->prop[PROP_CRTC_H] = prop_id;
		}
		else if (strcmp(prop->name, "SRC_X") == 0)
		{
			display->prop[PROP_SRC_X] = prop_id;
		}
		else if (strcmp(prop->name, "SRC_Y") == 0)
		{
			display->prop[PROP_SRC_Y] = prop_id;
		}
		else if (strcmp(prop->name, "SRC_W") == 0)
		{
			display->prop[PROP_SRC_W] = prop_id;
		}
		else if (strcmp(prop->name, "SRC_H") == 0)
		{
			display->prop[PROP_SRC_H] = prop_id;
		}
		else if (strcmp(prop->name, "zpos") == 0)
		{
			display->prop[PROP_ZPOS] = prop_id;
		}
		else if (strcmp(prop->name, "alpha") == 0)
		{
			display->prop[PROP_ALPHA] = prop_id;
		}
		else if (strcmp(prop->name, "alphaplane") == 0)
		{
			display->prop[PROP_ALPHAPLANE] = prop_id;
		}
		else if (strcmp(prop->name, "blend") == 0)
		{
			display->prop[PROP_BLEND] = prop_id;
		}
		else if (strcmp(prop->name, "ckey") == 0)
		{
			display->prop[PROP_CKEY] = prop_id;
		}
		else if (strcmp(prop->name, "ckey_set0") == 0)
		{
			display->prop[PROP_CKEY_SET0] = prop_id;
		}
		else if (strcmp(prop->name, "ckey_set1") == 0)
		{
			display->prop[PROP_CKEY_SET1] = prop_id;
		}

		drmModeFreeProperty(prop);
	}

	drmModeFreeObjectProperties(props);

	TRACE(INFO, _b("opened DRM device '%s', card-id: %d"), filename, id);

	if (0 && drmSetMaster(fd) != 0)
	{
		TRACE(ERROR, _x("failed to become master: %m"));
	}

	if (1)
	{
		drm_magic_t magic;

		if (drmGetMagic(fd, &magic) == 0)
		{
			TRACE(0, _b("master: %d"), drmAuthMagic(fd, magic));
		}
		else
		{
			TRACE(ERROR, _b("failed to get magic: %m"));
		}
	}

	return fd;
}

static int find_crtc(int fd, drmModeRes *resources, drmModeConnector *c)
{
	int             i, j;

	/* ...go through all available encoders */
	for (i = 0; i < c->count_encoders; i++)
	{
		drmModeEncoder *encoder;
		uint32_t        possible_crtcs;

		/* ...get encoder handle */
		CHK_ERR(encoder = drmModeGetEncoder(fd, c->encoders[i]), -errno);

		/* ...get mask of possible scanout-sources */
		possible_crtcs = encoder->possible_crtcs;

		/* ...release encoder handle */
		drmModeFreeEncoder(encoder);

		/* ...go through all scanout-sources (thrash; needs to be revised) */
		for (j = 0; j < resources->count_crtcs; j++)
		{
			if (possible_crtcs & (1 << j))
			{
				TRACE(INFO, _b("found suitable crtc #%d: %d"), j, resources->crtcs[j]);
				return j;
			}
		}
	}

	return -1;
}

/* ...select output device mode */
static int output_mode_supported(output_data_t *output, int width, int height)
{
	int                 i;

	for (i = 0; i < output->modes_num; i++)
	{
		drmModeModeInfo    *mode = &output->modes[i];

		if (mode->hdisplay == width && mode->vdisplay == height)
		{
			TRACE(INFO, _b("found mode %u*%u, refresh = %u, type=%X, flags=%X"),
					mode->hdisplay, mode->vdisplay, mode->vrefresh, mode->flags, mode->type);

			/* ...set mode pointer */
			output->current_mode = mode;

			return 0;
		}
	}

	return -1;
}

/* ...configure output device */
static output_data_t * create_output(display_data_t *display, drmModeRes *resources, drmModeConnector *c)
{
	output_data_t  *output;
	drmModeCrtc    *crtc;
	int             i;

	/* ...find encoder index */
	if ((i = find_crtc(display->fd, resources, c)) < 0)
	{
		TRACE(ERROR, _b("no encoder is found for connector"));
		return (errno = EINVAL, NULL);
	}

	/* ...create output device */
	CHK_ERR(output = calloc(1, sizeof(*output)), (errno = ENOMEM, NULL));

	/* ...set identifier */
	output->id = i;
	output->crtc = resources->crtcs[i];
	output->connector_id = c->connector_id;

	/* ...get current connector mode */
	if ((crtc = drmModeGetCrtc(display->fd, output->crtc)) == NULL)
	{
		TRACE(ERROR, _x("failed to get current mode: %m"));
		free(output);
		return NULL;
	}
	else if (!crtc->mode_valid)
	{
		TRACE(ERROR, _x("connector mode invalid"));
	}
	else
	{
		output->width = crtc->mode.hdisplay;
		output->height = crtc->mode.vdisplay;
		memcpy(&output->mode, &crtc->mode, sizeof(output->mode));
		output->current_mode = &output->mode;
	}

	/* ...save supported modes */
	if ((output->modes = malloc(sizeof(drmModeModeInfo) * c->count_modes)) == NULL)
	{
		TRACE(ERROR, _x("failed to allocate memory for %u modes"), c->count_modes);
		free(output);
		return NULL;
	}
	else
	{
		/* ...just make a copy of the modes */
		memcpy(output->modes, c->modes, sizeof(drmModeModeInfo) * c->count_modes);
		output->modes_num = c->count_modes;
	}

	/* ...get list of modes */
	for (i = 0; i < (int)c->count_modes; i++)
	{
		drmModeModeInfo    *mode = &c->modes[i];

		TRACE(INFO, _b("mode[%d]: %u*%u"), i, mode->hdisplay, mode->vdisplay);
	}

	/* ...put output into list */
	__list_push_tail(&display->outputs, &output->link);

	TRACE(INFO, _b("connector #%d: type=%d, id=%d, subpixel=%d, mode: %d*%d, cid=%u"), output->id, c->connector_type, c->connector_type_id, c->subpixel, output->width, output->height, output->connector_id);

	return output;
}

/* ...create output devices (hmm) */
static int create_outputs(display_data_t *display)
{
	drmModeConnector   *connector;
	drmModeRes         *resources;
	int                 i;
	int                 retval;

	CHK_ERR(resources = drmModeGetResources(display->fd), -errno);

	/* ...process all available connectors */
	for (i = 0; i < resources->count_connectors; i++)
	{
		if ((connector = drmModeGetConnector(display->fd, resources->connectors[i])) == NULL)
		{
			TRACE(ERROR, _x("failed to obtain connector #%d handle: %m"), i);
			retval = -errno;
			goto out;
		}

		TRACE(INFO, _b("connector #%d: id=%d, connection=%d"), i, connector->connector_id, connector->connection);

		/* ...put connector-id into the list of outputs? - tbd */
		create_output(display, resources, connector);

		/* ...release connector data */
		drmModeFreeConnector(connector);
	}

	retval = 0;

out:
	drmModeFreeResources(resources);
	return retval;
}

/*******************************************************************************
 * Internal helpers
 ******************************************************************************/

/*******************************************************************************
 * Display dispatch thread
 ******************************************************************************/

/* ...number of events expected */
#define DISPLAY_EVENTS_NUM      4

/* ...get output device by number */
static output_data_t *display_get_output(display_data_t *display, int n)
{
	__list_t       *list = &display->outputs, *item;

	/* ...traverse available outputs list */
	for (item = list_first(list); item != list_null(list); item = list_next(list, item))
	{
		output_data_t  *output = container_of(item, output_data_t, link);

		/* ...check for identifier */
		if (output->id == n)    return  output;
	}

	/* ...not found */
	return NULL;
}


/*******************************************************************************
 * Basic widgets support
 ******************************************************************************/

/* ...internal widget initialization function */
static int __widget_init(widget_data_t *widget, window_data_t *window, int W, int H, widget_info_t *info, void *cdata)
{
	int                 w, h;

	/* ...set user-supplied data */
	widget->info = info, widget->cdata = cdata;

	/* ...set pointer to the owning window */
	widget->window = window;

	/* ...if width/height are not specified, take them from window */
	widget->width = w = (info && info->width ? info->width : W);
	widget->height = h = (info && info->height ? info->height : H);
	widget->top = (info ? info->top : 0);
	widget->left = (info ? info->left : 0);

	/* ...initialize widget controls as needed */
	if (info && info->init)
	{
		if (info->init(widget, cdata) < 0)
		{
			TRACE(ERROR, _x("widget initialization failed: %m"));
			goto error;
		}

		/* ...mark widget is dirty */
		widget->dirty = 1;
	}
	else
	{
		/* ...clear dirty flag */
		widget->dirty = 0;
	}

	TRACE(INIT, _b("widget [%p] initialized"), widget);

	return 0;

error:
	return -1;    
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

/* ...create native window */
window_data_t * window_create(display_data_t *display, window_info_t *info, widget_info_t *info2, void *cdata)
{
	int                 width = info->width;
	int                 height = info->height;
	output_data_t      *output;
	window_data_t      *window;

	/* ...make sure we have a valid output device */
	if ((output = display_get_output(display, info->output)) == NULL)
	{
		TRACE(ERROR, _b("invalid output device number: %u"), info->output);
		errno = EINVAL;
		return NULL;
	}

	/* ...if width/height are not specified, use output device dimensions */
	(!width ? width = output->width : 0), (!height ? height = output->height : 0);

	/* ...check if the output mode needs to be changed */
	if ((uint32_t)width != output->width || (uint32_t)height != output->width)
	{
		if (output_mode_supported(output, width, height) < 0)
		{
			TRACE(ERROR, _b("output mode %d*%d not supported"), width, height);
			errno = EINVAL;
			return NULL;
		}
	}

	/* ...allocate a window data */
	if ((window = calloc(1, sizeof(*window))) == NULL)
	{
		TRACE(ERROR, _x("failed to allocate memory"));
		errno = ENOMEM;
		return NULL;
	}

	/* ...save output device handle */
	window->output = output;

	/* ...initialize window data access lock */
	pthread_mutex_init(&window->lock, NULL);

	/* ...initialize conditional variable for communication with rendering thread */
	pthread_cond_init(&window->wait, NULL);

	/* ...save display handle */
	window->display = display;

	/* ...save window info data */
	window->info = info, window->cdata = cdata;

	/* ...clear window flags */
	window->flags = 0;

	/* ...set window mode */
	if (1 && (window->flags & WINDOW_FLAG_MODESET) == 0)
	{
		drmModeCrtcPtr  crtc;

		if (drmModeSetCrtc(display->fd, output->crtc, -1, 0, 0, &output->connector_id, 1, output->current_mode) < 0)
		{
			TRACE(ERROR, _x("mode-set failed: %m"));
		}

		if ((crtc = drmModeGetCrtc(display->fd, output->crtc)) != NULL)
		{
			TRACE(INIT, _b("crtc: %u * %u, mode-valid: %d (%u*%u@%u)"), crtc->width, crtc->height, crtc->mode_valid, crtc->mode.hdisplay, crtc->mode.vdisplay, crtc->mode.vrefresh);
		}

		/* ...mark mode is set */
		window->flags |= WINDOW_FLAG_MODESET;
	}

	/* ...allocate atomic request structure for compositing */
	if ((window->atomic_req = drmModeAtomicAlloc()) == NULL)
	{
		TRACE(ERROR, _x("failed to allocate atomic request: %m"));
		goto error;
	}

	/* ...initialize root widget data */
	if (__widget_init(&window->widget, window, width, height, info2, cdata) < 0)
	{
		TRACE(INIT, _b("widget initialization failed: %m"));
		goto error;
	}

	/* ...add window to global display list */
	__list_push_tail(&display->windows, &window->link);

	TRACE(INFO, _b("window created: %p, %u*%u, output: %u"), window, width, height, info->output);

	return window;

error:
	/* ...destroy window memory */
	free(window);
	return NULL;
}

/* ...destroy a window */
void window_destroy(window_data_t *window)
{
	//display_data_t         *display = window->display;
	const window_info_t    *info = window->info;
	const widget_info_t    *info2 = window->widget.info;

	/* ...terminate window rendering thread */
	pthread_mutex_lock(&window->lock);
	window->flags |= WINDOW_FLAG_TERMINATE;
	pthread_cond_signal(&window->wait);
	pthread_mutex_unlock(&window->lock);

	/* ...wait until thread completes */
	pthread_join(window->thread, NULL);

	TRACE(DEBUG, _b("window[%p] thread joined"), window);

	/* ...remove window from global display list */
	__list_delete(&window->link);

	/* ...invoke custom widget destructor function as needed */
	(info2 && info2->destroy ? info2->destroy(&window->widget, window->cdata) : 0);

	/* ...invoke custom window destructor function as needed */
	(info && info->destroy ? info->destroy(window, window->cdata) : 0);

	/* ...destroy window lock */
	pthread_mutex_destroy(&window->lock);

	/* ...destroy rendering thread conditional variable */
	pthread_cond_destroy(&window->wait);

	/* ...destroy object */
	free(window);

	TRACE(INFO, _b("window[%p] destroyed"), window);
}

/* ...return current window width */
int window_get_width(window_data_t *window)
{
	return window->widget.width;
}

/* ...return current window height */
int window_get_height(window_data_t *window)
{
	return window->widget.height;
}

/* ...submit window to a renderer */
void window_draw(window_data_t *window)
{
	display_data_t         *display = window->display;

	/* ...mark window is busy */
	pthread_mutex_lock(&window->lock);

	/* ...submit atomic request (modeset allow? - tbd) */
	if (drmModeAtomicCommit(display->fd, window->atomic_req, 0*DRM_MODE_PAGE_FLIP_EVENT | 0*DRM_MODE_ATOMIC_NONBLOCK | DRM_MODE_ATOMIC_ALLOW_MODESET, window) < 0)
	{
		TRACE(ERROR, _x("commit failed: %m"));
	}

	/* ...reset cursor once drawing operation has been submitted */
	drmModeAtomicSetCursor(window->atomic_req, 0);

	pthread_mutex_unlock(&window->lock);
}

/*******************************************************************************
 * Display module initialization
 ******************************************************************************/

/* ...create display data */
display_data_t * display_create(void)
{
	display_data_t     *display = &__display;
	struct udev        *udev;
	struct udev_device *drm_device;

	/* ...reset display data */
	memset(display, 0, sizeof(*display));

	/* ...create udev handle */
	if ((udev = udev_new()) == NULL)
	{
		TRACE(ERROR, _x("failed to connect to udev: %m"));
		goto error;
	}

	/* ...basic initialization of DRM */
	if ((drm_device = find_drm(udev, NULL)) == NULL)
	{
		TRACE(ERROR, _x("cannot found default DRM device: %m"));
		goto error_udev;
	}

	if ((display->fd = init_drm(drm_device)) < 0)
	{
		TRACE(ERROR, _x("failed to initialize DRM: %m"));
		goto error_udev;
	}

	/* ...initialize inputs/outputs lists */
	__list_init(&display->outputs);

	/* ...initialize windows list */
	__list_init(&display->windows);

	if (create_outputs(display) < 0)
	{
		TRACE(ERROR, _x("failed to enumerate outputs"));
		goto error_udev;
	}

	/* ...wait until display thread starts? */
	TRACE(INIT, _b("DRM display interface initialized"));

	return display;

error_udev:
	udev_unref(udev);

error:
	return NULL;
}

/*******************************************************************************
 * Textures handling
 ******************************************************************************/

/* ...calculate cropping and viewport parameters for a texture */
void texture_set_view(texture_view_t *vcoord, int x0, int y0, int x1, int y1)
{
	(*vcoord)[0] = x0;
	(*vcoord)[1] = y0;
	(*vcoord)[2] = x1;
	(*vcoord)[3] = y1;
}

/* ...set texture cropping data */
void texture_set_crop(texture_crop_t *tcoord, int x0, int y0, int x1, int y1)
{
	(*tcoord)[0] = x0;
	(*tcoord)[1] = y0;
	(*tcoord)[2] = x1;
	(*tcoord)[3] = y1;
}

static inline int texture_view_x0(texture_view_t *v)
{
	return (*v)[0];    
}

static inline int texture_view_y0(texture_view_t *v)
{
	return (*v)[1];
}

static inline int texture_view_x1(texture_view_t *v)
{
	return (*v)[2];
}

static inline int texture_view_y1(texture_view_t *v)
{
	return (*v)[3];
}

static inline float texture_view_width(texture_view_t *v)
{
	return ((*v)[2] - (*v)[0]);    
}

static inline float texture_view_height(texture_view_t *v)
{
	return ((*v)[3] - (*v)[1]);
}

/* ...texture creation for given set of DMA-file-descriptors */
texture_data_t * texture_create(int w, int h, uint32_t format, int dmafd, unsigned *offset, unsigned *stride)
{
	display_data_t                 *display = &__display;
	uint32_t                        handle[4];
	texture_data_t                 *texture;

	/* ...allocate texture data */
	CHK_ERR(texture = malloc(sizeof(*texture)), (errno = ENOMEM, NULL));

	/* ...map buffer planes */
	TRACE(ERROR, _x("creating buffer handle for dma-fd %d: %m"), dmafd);
	if (drmPrimeFDToHandle(display->fd, dmafd, &handle[0]) != 0)
	{
		TRACE(ERROR, _x("failed to create buffer handle for dma-fd %d: %m"), dmafd);
		goto error;
	}

	if (drmModeAddFB2(display->fd, w, h, format, handle, stride, offset, &texture->fb_id, 0) != 0)
	{
		TRACE(ERROR, _x("failed to create FB2: %m"));
		goto error;
	}

	goto out;

error:
	/* ...buffer creation failed; destroy texture object */
	free(texture), texture = NULL;

	/* ...pass through */
out:
	/* ...close handles */
	{
		struct drm_gem_close gem_close = {.handle = handle[0]};

		drmIoctl(display->fd, DRM_IOCTL_GEM_CLOSE, &gem_close);
	}

	return texture;
}

/* ...destroy texture data */
void texture_destroy(texture_data_t *texture)
{
	display_data_t *display = &__display;

	/* ...destroy framebuffer object */
	(texture->fb_id ? drmModeRmFB(display->fd, texture->fb_id) : 0);

	/* ...destroy texture structure */
	free(texture);
}

/*******************************************************************************
 * Planes support
 ******************************************************************************/

/* ...setup DRM overlay plane */
int plane_setup(window_data_t *window, int i, texture_data_t *texture, texture_data_t *alpha, u8 tr, texture_view_t *view, texture_view_t *crop, u32 *ckey, u32 blend)
{
	display_data_t         *display = window->display;
	output_data_t          *output = window->output;
	uint32_t                plane_id;
	uint32_t                x0, y0, w, h;
	uint32_t                X0, Y0, W, H;
	drmModeAtomicReqPtr     req;

	/* ...view-port setup */
	if (!view)
	{
		x0 = 0, y0 = 0, w = window_get_width(window), h = window_get_height(window);
	}
	else
	{
		x0 = texture_view_x0(view), y0 = texture_view_y0(view);
		w = texture_view_width(view), h = texture_view_height(view);

		TRACE(0, _b("viewport: %u/%u/%u/%u"), x0, y0, w, h);
	}

	/* ...crop-region setup */
	if (!crop)
	{
		X0 = x0 << 16, Y0 = y0 << 16, W = w << 16, H = h << 16;
	}
	else
	{
		int        *p = *crop;

		X0 = p[0] << 16, Y0 = p[1] << 16, W = (p[2] - p[0]) << 16, H = (p[3] - p[1]) << 16;

		TRACE(0, _b("crop: %u/%u/%u/%u"), X0, Y0, W, H);
	}

	/* ...get plane identifier */
	CHK_ERR(plane_id = display->plane_id[i], -(errno = ENODEV));

	/* ...get atomic request structure */
	req = window->atomic_req;

	if (texture)
	{
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CRTC_ID], output->crtc));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_FB_ID], texture->fb_id));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CRTC_X], x0));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CRTC_Y], y0));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CRTC_W], w));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CRTC_H], h));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_SRC_X], X0));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_SRC_Y], Y0));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_SRC_W], W));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_SRC_H], H));
	}
	else
	{
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CRTC_ID], 0));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_FB_ID], 0));
	}

	/* ...set apha-plane property */
	CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_ALPHAPLANE], (alpha ? alpha->fb_id : 0)));

	/* ...set global alpha value */
	CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_ALPHA], tr));

	/* ...set blending property */
	CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_BLEND], blend));

	/* ...set color key if needed */
	if (ckey)
	{
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CKEY], ckey[0]));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CKEY_SET0], ckey[1]));
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CKEY_SET1], ckey[2]));
	}
	else
	{
		CHK_API(drmModeAtomicAddProperty(req, plane_id, display->prop[PROP_CKEY], 0));
	}

	return 0;
}
