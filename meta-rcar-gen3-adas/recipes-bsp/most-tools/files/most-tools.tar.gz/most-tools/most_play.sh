#!/bin/sh

gst-launch-1.0 filesrc location=$1 ! mpegaudioparse ! avdec_mp3 ! audioconvert ! audioresample ! alsasink device='hw:'$2',0'
