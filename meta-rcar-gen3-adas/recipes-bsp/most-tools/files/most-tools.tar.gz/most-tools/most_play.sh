#!/bin/sh

gst-launch-1.0 filesrc location=$1 ! decodebin ! audioconvert ! audioresample ! alsasink device='hw:'$2',0'
